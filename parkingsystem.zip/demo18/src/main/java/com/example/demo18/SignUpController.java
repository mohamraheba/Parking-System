package com.example.demo18;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import org.w3c.dom.Text;

import java.sql.Connection;
import java.sql.Statement;

public class SignUpController {
    @FXML
    private Button closeButton;
    @FXML
    private Label signUpMessage;
    @FXML
    private TextField userNameTextField;
    @FXML
    private PasswordField passwordField;

    public void signUpButtonOnAction(ActionEvent event){
        if (userNameTextField.getText().isBlank() == false && passwordField.getText().isBlank() == false){
            signUpUser();
            signUpMessage.setText("you clicked");
        } else{
            signUpMessage.setText("Please enter username or password");
        }
    }
    public void CloseButtonOnAction(ActionEvent event){
        Stage stage = (Stage) closeButton.getScene().getWindow();
        stage.close();
    }
    public void signUpUser(){
        DataBaseConnection connection = new DataBaseConnection();
        Connection connectDB = connection.getConnection();

        String username = userNameTextField.getText();
        String password = passwordField.getText();

//        String insertField = "INSERT INTO users(user_name, password) VALUES ('";
//        String insertValues = username + "','" + password + "')";
//        String insertToSignUp = insertField + insertValues;
        String insertField = "INSERT INTO users(user_name, password) VALUES ('" + username + "','" + password + "')";


        try{
            Statement stmt = connectDB.createStatement();
            stmt.executeUpdate(insertField);

            signUpMessage.setText("Sign Up successfully");
        } catch (Exception e){
            e.printStackTrace();
        }

    }
}

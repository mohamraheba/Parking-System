package com.example.parking_system;

public enum UserRole {
    ADMIN, USER;
}
